package com.supermarche;

public class Main {

    public static void main(String[] args) {

    }
}
